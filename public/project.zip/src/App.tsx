import { useEffect } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { RouterProvider, useRouter } from '@/context/RouterContext';
import { LoadingScreen } from '@/components/LoadingScreen';
import { LandingPage } from '@/pages/LandingPage';
import { LoginPage } from '@/pages/auth/LoginPage';
import { SignupPage } from '@/pages/auth/SignupPage';
import { ForgotPasswordPage } from '@/pages/auth/ForgotPasswordPage';
import { EmailValidationPage } from '@/pages/auth/EmailValidationPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { AnalyzePage } from '@/pages/AnalyzePage';
import { HistoryPage } from '@/pages/HistoryPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { SettingsPage } from '@/pages/SettingsPage';

const PROTECTED = ['/dashboard', '/analyze', '/history', '/profile', '/settings'];
const AUTH_PAGES = ['/login', '/signup', '/forgot-password', '/email-validation'];

function Routes() {
  const { path, navigate } = useRouter();
  const { session, loading } = useAuth();

  useEffect(() => {
    if (loading) return;
    const isProtected = PROTECTED.some((p) => path === p || path.startsWith(p + '/'));
    const isAuthPage = AUTH_PAGES.some((p) => path === p);
    if (isProtected && !session) {
      if (path !== '/login') navigate('/login');
    } else if (isAuthPage && session) {
      if (path !== '/dashboard') navigate('/dashboard');
    }
  }, [path, session, loading, navigate]);

  if (loading) return <LoadingScreen />;

  switch (path) {
    case '/':
      return <LandingPage />;
    case '/login':
      return <LoginPage />;
    case '/signup':
      return <SignupPage />;
    case '/forgot-password':
      return <ForgotPasswordPage />;
    case '/email-validation':
      return <EmailValidationPage />;
    case '/dashboard':
      return <DashboardPage />;
    case '/analyze':
      return <AnalyzePage />;
    case '/history':
      return <HistoryPage />;
    case '/profile':
      return <ProfilePage />;
    case '/settings':
      return <SettingsPage />;
    default:
      return <LandingPage />;
  }
}

export default function App() {
  return (
    <AuthProvider>
      <RouterProvider>
        <Routes />
      </RouterProvider>
    </AuthProvider>
  );
}
